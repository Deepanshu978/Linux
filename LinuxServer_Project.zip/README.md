# Linux Server Setup with MySQL, PHP, and AWS CloudWatch Monitoring

## 🛠️ Project Summary
This repo documents a hands-on setup of a Linux environment with:
- MySQL installation and configuration
- PHP-MySQL integration test
- CloudWatch Agent setup and monitoring from AWS

## 🐘 MySQL Table Used
```sql
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100)
);
INSERT INTO users (name, email) VALUES ('Deep', 'deep@example.com');
```

## 📄 Files Included
- `dbtest.php`: Tests PHP-MySQL connectivity and displays data.
- `cloudwatch-config.json`: Configuration file for AWS CloudWatch Agent.
